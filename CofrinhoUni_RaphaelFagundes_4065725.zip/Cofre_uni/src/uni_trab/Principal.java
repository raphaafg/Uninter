package uni_trab;


import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int acao;
        
        do {        	
        	System.out.println(""); 
        	System.out.println("\n---------------------------"); 
        	System.out.println("Bem vindo ao seu Cofrinho!");  //apresentação do menu de ações do Cofrinho
        	System.out.println("---------------------------");
            System.out.println("----- MENU DO COFRE -----");
            System.out.println("1 - Adicionar uma moeda");
            System.out.println("2 - Remover uma moeda");
            System.out.println("3 - Listar todas as moedas");
            System.out.println("4 - Calcular total em reais dentro do Cofrinho");
            System.out.println("5 - Sair do Cofrinho");
            System.out.print("Escolha uma ação: ");
            acao = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (acao) { //comparacao de input de entrada do teclado para selecao de acao do programa
            
            
                case 1: //1 - Adicionar uma moeda
                    
                    System.out.println("Escolha o tipo de moeda:");
                    System.out.println("1 - $  Dólar");
                    System.out.println("2 - €  Euro");
                    System.out.println("3 - R$ Real");
                    System.out.print("Moeda em: ");
                    int tipo = scanner.nextInt();
                    scanner.nextLine(); 
                    
                    System.out.print("Digite o valor desta moeda: ");
                    double valor = scanner.nextDouble();
                    scanner.nextLine();
                    
                    switch (tipo) {
                        case 1:
                            cofrinho.adicionarMoeda(new Dolar(valor));
                            break;
                        case 2:
                            cofrinho.adicionarMoeda(new Euro(valor));
                            break;
                        case 3:
                            cofrinho.adicionarMoeda(new Real(valor));
                            break;
                        default:
                            System.out.println("O tipo da moeda é inválido.");
                    }
                    break;
                    
                    
                case 2: //2 - Remover uma moeda
                    
                    System.out.println("Lista de moedas no Cofrinho:");
                    cofrinho.listarMoedas();
                    System.out.print("Digite o índice da moeda que quer remover: ");
                    int indice = scanner.nextInt();
                    scanner.nextLine(); 
                    
                    if (cofrinho.removerMoedaPorIndice(indice)) {
                        System.out.println("Moeda removida com sucesso!");
                    } else {
                        System.out.println("Índice escolhido não existe...");
                    }
                    break;
                    
                    
                case 3: //3 - Listar todas as moedas
                    
                    System.out.println("Moedas no cofrinho:");
                    cofrinho.listarMoedas();
                    break;
                    
                    
                case 4: //4 - Calcular total em reais dentro do Cofrinho
                    
                    double total = cofrinho.calcularTotalConvertido();
                    System.out.println("Valor total em Reais: R$ " + total);
                    break;
                    
                    
                case 5: //5 - Sair do Cofrinho
                	
                	System.out.println("Saindo do Cofrinho...");
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (acao != 5);
        
        scanner.close();
    }
}
