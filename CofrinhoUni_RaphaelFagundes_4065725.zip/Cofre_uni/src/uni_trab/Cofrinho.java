package uni_trab;


import java.util.ArrayList;

public class Cofrinho {
    private ArrayList<Moeda> moedas;
    
    public Cofrinho() {
        moedas = new ArrayList<>();
    }
    
    public void adicionarMoeda(Moeda m) { //metodo de adicionar uma moeda ao cofrinho
        if (m.getValor() <= 0) { //check do valor da moeda para valores possíveis, ou seja, maior que 0
            System.out.println("Valor inválido: a moeda deve ter valor maior que 0.");
            return;
        }
        moedas.add(m);
    }

          
    public boolean removerMoedaPorIndice(int indice) { //metodo de remover uma moeda do cofrinho pelo índice
        if (indice >= 0 && indice < moedas.size()) {
            moedas.remove(indice);
            return true;
        }
        return false;
    }
    
    
    public ArrayList<Moeda> getMoedas() { //metodo de retornar a lista de moedas
        return moedas;
    }
    
    
    public double calcularTotalConvertido() { //metodo de calcular o total em reais
        double total = 0.0;
        for (Moeda m : moedas) {
            total += m.converterParaReal();
        }
        return total;
    }
    
    
    public void listarMoedas() { //metodo de exibicao das moedas armazenadas com um índice
        if (moedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
            System.out.println("");
        } else {
            for (int i = 0; i < moedas.size(); i++) {
                System.out.println("[" + i + "] " + moedas.get(i).toString());
            }
        }
    }
}
