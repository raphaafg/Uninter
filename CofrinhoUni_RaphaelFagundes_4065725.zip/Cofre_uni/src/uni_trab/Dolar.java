package uni_trab;


public class Dolar extends Moeda { //extends usado pq é herdeira de Moeda
    private static final double CONVERSAO_PARA_REAL = 5.7; // constante privada para calculo de conversao do dolar
    
    public Dolar(double valor) {
        super(valor); //ref herdada
    }
    
    @Override
    public double converterParaReal() {  //realiza conversao do valor em real da moeda
        return valor * CONVERSAO_PARA_REAL;
    }
    
    @Override
    public String toString() { 
        return "Dólar $  - " + super.toString() + " | Convertido: " + " R$" + converterParaReal();
    }
}
