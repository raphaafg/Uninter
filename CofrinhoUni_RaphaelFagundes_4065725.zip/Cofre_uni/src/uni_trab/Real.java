package uni_trab;


public class Real extends Moeda { //extends usado pq é herdeira de Moeda
    //nao possui constante de conversao já que nao sera usada
	
    public Real(double valor) {
        super(valor); //mais uma vez ref herdada
    }
    
    @Override
    public double converterParaReal() {
        return valor; //valor ja esta em reais, nao realiza operaçao
    }
    
    @Override
    public String toString() {
        return "Real R$ - " + super.toString() + " | Convertido: " + " R$" + converterParaReal();
    }
}
