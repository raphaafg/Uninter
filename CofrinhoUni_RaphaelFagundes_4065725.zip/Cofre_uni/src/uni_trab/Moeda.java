package uni_trab;


public abstract class Moeda { //classe herdada em Dolar, Euro e Real
    protected double valor;
    
    public Moeda(double valor) {
        this.valor = valor;
    }
    
   
    public abstract double converterParaReal();  //Método da conversao do valor da moeda para real
    
    
    public double getValor() { // Get para adquirir valor
        return valor;
    }
    
    @Override
    public String toString() {
        return "Valor: " + valor;
    }
}

